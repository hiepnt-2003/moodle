<?php
$string['pluginname'] = 'Hello World Block';
$string['helloworld'] = 'Hello World';
$string['plugincontent'] = 'Hello Moodle!';
$string['helloworld:addinstance'] = 'Add a new Hello World block';
$string['helloworld:myaddinstance'] = 'Add a new Hello World block to Dashboard';
