<?php
$string['pluginname'] = 'My Data Block';
$string['mydata:addinstance'] = 'Add a new My Data block';
$string['mydata:myaddinstance'] = 'Add a new My Data block to Dashboard';
