<?php
$string['pluginname'] = 'Hello World Block';
$string['helloworld'] = 'Hello World';
$string['plugincontent'] = 'Hello Moodle!';
$string['configmessage'] = 'Message to display';
$string['configmessage_desc'] = 'Text displayed inside the block instance.';
$string['defaultmessage'] = 'Default message';
$string['defaultmessage_desc'] = 'Default message shown when instance has no custom message.';
$string['helloworld:addinstance'] = 'Add a new Hello World block';
$string['helloworld:myaddinstance'] = 'Add a new Hello World block to Dashboard';
