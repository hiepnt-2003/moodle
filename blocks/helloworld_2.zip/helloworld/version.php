<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_helloworld';   // Tên định danh plugin
$plugin->version   = 2025092400;           // YYYYMMDDXX - build
$plugin->requires  = 2022041900;           // Moodle minimum required (ví dụ)
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0 (2025-09-24)';
