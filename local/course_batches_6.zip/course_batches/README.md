# Plugin Quản lý Đợt Mở Môn (Course Batches) cho Moodle

Plugin local Moodle để quản lý đợt mở môn đơn giản. Plugin tự động nhóm các khóa học có cùng ngày bắt đầu thành các đợt mở môn.

## Logic hoạt động
**Nguyên tắc phân loại**: Khóa học được tự động thêm vào đợt mở môn nếu có **cùng ngày bắt đầu** (`startdate`) với đợt mở môn.

**Ví dụ**: 
- Đợt mở môn: 01/01/2025
- Khóa học A: startdate = 01/01/2025 → **Được thêm vào đợt**
- Khóa học B: startdate = 15/01/2025 → **Không được thêm** (khác ngày bắt đầu)
- Khóa học C: startdate = 01/01/2025 → **Được thêm vào đợt** (cùng ngày bắt đầu)

## Tính năng chính
1. **Cấu trúc đơn giản**: 
   - Bảng `local_course_batches` để lưu trữ thông tin đợt mở môn (chỉ có ngày bắt đầu)
   - Bảng `local_course_batch_courses` để lưu trữ mối liên hệ giữa đợt và khóa học
2. **Tự động tạo đợt theo ngày bắt đầu**: 
   - Phân tích tất cả các ngày bắt đầu (startdate) duy nhất từ khóa học
   - Tạo đợt mở môn cho mỗi ngày bắt đầu
   - Tự động gán khóa học có cùng startdate vào đợt
3. **Quản lý đợt mở môn đơn giản**: 
   - Thêm, sửa, xóa các đợt mở môn với ngày bắt đầu cụ thể
   - Validation: không trùng lặp ngày bắt đầu
4. **Tự động gán khóa học**: 
   - Gán dựa trên ngày bắt đầu giống nhau
   - Khi tạo/sửa đợt → tự động cập nhật danh sách khóa học
   - Có thể gán/bỏ gán thủ công
5. **Hiển thị dữ liệu trực quan**: 
   - Dashboard thống kê tổng quan
   - Hiển thị ngày bắt đầu của đợt và từng khóa học
   - Danh sách khóa học chưa được gán vào đợt nào
6. **Import từ Moodle**: 
   - Môn học được lấy từ bảng course của Moodle
   - Tự động đồng bộ khi có khóa học mới

## Cấu trúc bảng cơ sở dữ liệu

### Bảng: `local_course_batches`
- `id` (int): Khóa chính
- `batch_name` (varchar 255): Tên đợt mở môn
- `start_date` (int): Ngày bắt đầu học của đợt (timestamp)
- `created_date` (int): Ngày tạo record (timestamp)

### Bảng: `local_course_batch_courses`
- `id` (int): Khóa chính
- `batchid` (int): ID đợt mở môn (khóa ngoại)
- `courseid` (int): ID khóa học (khóa ngoại)
- `timecreated` (int): Thời gian thêm vào đợt (timestamp)

## Cài đặt

1. **Sao chép plugin**: 
   - Sao chép thư mục `course_batches` vào `[moodle]/local/`

2. **Cài đặt qua Moodle Admin**:
   - Đăng nhập với quyền admin
   - Vào Site Administration > Notifications
   - Moodle sẽ tự động phát hiện plugin mới và yêu cầu cài đặt
   - Nhấn "Upgrade Moodle database now"

3. **Phân quyền**:
   - Vào Site Administration > Users > Permissions > Define roles
   - Gán quyền `local/course_batches:view` và `local/course_batches:manage` cho các role phù hợp

## Sử dụng

### 1. Truy cập plugin
- Vào Site Administration > Plugins > Local plugins > Course Batches
- Hoặc truy cập trực tiếp: `[moodle_url]/local/course_batches/`

### 2. Tự động tạo đợt mở môn
- Nhấn nút "Tự động tạo đợt từ khóa học"
- Plugin sẽ phân tích tất cả khóa học và tạo đợt mở môn dựa trên ngày bắt đầu

### 3. Quản lý thủ công
- **Thêm đợt mới**: Nhấn "Thêm đợt mở môn", nhập tên đợt và ngày bắt đầu học
- **Sửa đợt**: Nhấn nút "Sửa" trong danh sách (sẽ tự động cập nhật khóa học khi thay đổi ngày bắt đầu)
- **Xóa đợt**: Nhấn nút "Xóa" (có xác nhận)
- **Xem khóa học**: Nhấn "Xem khóa học" để xem chi tiết các khóa học trong đợt
- **Quản lý khóa học**: Trong trang chi tiết đợt có thể gán/bỏ gán khóa học thủ công

### 4. Hiển thị thông tin
- **Dashboard thống kê**: Tổng số đợt, khóa học đã gán, chưa gán, tổng khóa học
- **Danh sách đợt mở môn**: Tên đợt, **ngày bắt đầu học**, ngày tạo, số khóa học, các thao tác
- **Chi tiết khóa học trong đợt**: Tên khóa học, tên viết tắt, **thời gian khóa học**, trạng thái, số học viên, ngày thêm vào đợt
- **Quản lý khóa học**: 
  - Tab "Khóa học trong đợt": Danh sách khóa học đã gán với nút xóa khỏi đợt
  - Tab "Khóa học chưa gán": Danh sách khóa học chưa gán với nút thêm vào đợt

### 5. Mối liên hệ đợt - khóa học (LOGIC ĐƠN GIẢN)
- **Liên kết theo ngày bắt đầu**: Khóa học được gán vào đợt nếu có cùng ngày bắt đầu
- **Điều kiện gán**: `course.startdate = batch.start_date`
- **Gán thủ công**: Admin có thể gán/bỏ gán khóa học vào/khỏi đợt bất kỳ
- **Cập nhật tự động**: Khi sửa ngày bắt đầu đợt, danh sách khóa học được cập nhật tự động
- **Theo dõi lịch sử**: Ghi lại thời gian thêm khóa học vào đợt
- **Import từ Moodle**: Môn học được lấy từ bảng course của Moodle

## Quyền truy cập

### `local/course_batches:view`
- Xem danh sách đợt mở môn
- Xem chi tiết khóa học trong đợt
- Mặc định gán cho: Manager, Course Creator, Editing Teacher

### `local/course_batches:manage`
- Tất cả quyền của `view`
- Thêm, sửa, xóa đợt mở môn
- Tự động tạo đợt từ dữ liệu khóa học
- Mặc định gán cho: Manager

## Cấu trúc file

```
local/course_batches/
├── version.php                    # Thông tin phiên bản plugin
├── index.php                      # Trang chính hiển thị danh sách đợt + dashboard
├── manage.php                     # Trang thêm/sửa đợt mở môn
├── manage_courses.php             # Trang quản lý khóa học trong đợt
├── db/
│   ├── install.xml               # Cấu trúc bảng cơ sở dữ liệu
│   ├── upgrade.php               # Script nâng cấp database
│   └── access.php                # Định nghĩa quyền truy cập
├── lang/en/
│   └── local_course_batches.php  # Chuỗi ngôn ngữ tiếng Việt
├── classes/
│   └── batch_manager.php         # Class quản lý logic nghiệp vụ
└── README.md                     # File hướng dẫn này
```

## Ghi chú kỹ thuật

- Plugin tuân thủ coding standards của Moodle
- Sử dụng Moodle API để tương tác với cơ sở dữ liệu
- Responsive design tương thích với theme Bootstrap của Moodle
- Hỗ trợ đa ngôn ngữ (hiện tại có tiếng Việt)

## Phiên bản
- **v1.0** (2025-09-25): Phiên bản đầu tiên - gán theo startdate
- **v1.1** (2025-09-25): 
  - Thêm bảng liên kết `local_course_batch_courses`
  - Cải thiện mối liên hệ giữa đợt và khóa học
  - Thêm dashboard thống kê
  - Thêm trang quản lý khóa học trong đợt
  - Theo dõi lịch sử thêm khóa học vào đợt
- **v1.2** (2025-09-25): Gán theo khoảng thời gian
  - Thêm trường `end_date` và `description`
  - Logic gán dựa trên khoảng thời gian (startdate + enddate)
- **v1.3** (2025-09-25): **ĐƠN GIẢN HÓA CẤU TRÚC**
  - **Loại bỏ**: `end_date` và `description` khỏi bảng đợt mở môn
  - **Quay lại logic đơn giản**: Chỉ gán theo startdate
  - **Tối ưu**: Cấu trúc đơn giản, dễ quản lý
  - **Phù hợp yêu cầu**: Đợt gồm id, tên đợt, ngày tạo, ngày bắt đầu
  - **Môn học cùng đợt**: Có cùng startdate