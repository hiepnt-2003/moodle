<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY { without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Trang quản lý môn học
 *
 * @package    local_course_batches
 * @copyright  2025 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/course_subject_manager.php');

require_login();
$context = context_system::instance();
require_capability('local/course_batches:view', $context);

$PAGE->set_url('/local/course_batches/subjects.php');
$PAGE->set_context($context);
$PAGE->set_title('Quản lý môn học');
$PAGE->set_heading('Quản lý môn học');

// Lấy tham số
$action = optional_param('action', '', PARAM_ALPHA);
$subject_id = optional_param('subject_id', 0, PARAM_INT);
$batch_id = optional_param('batch_id', 0, PARAM_INT);

// Xử lý actions
if ($action && confirm_sesskey()) {
    switch ($action) {
        case 'update_subject':
            if ($subject_id) {
                $success = local_course_batches\course_subject_manager::update_subject_from_moodle($subject_id);
                if ($success) {
                    redirect($PAGE->url, 'Đã cập nhật thông tin môn học', null, \core\output\notification::NOTIFY_SUCCESS);
                } else {
                    redirect($PAGE->url, 'Không thể cập nhật môn học', null, \core\output\notification::NOTIFY_ERROR);
                }
            }
            break;
            
        case 'add_to_batch':
            if ($subject_id && $batch_id) {
                $success = local_course_batches\course_subject_manager::add_subject_to_batch($batch_id, $subject_id);
                if ($success) {
                    redirect($PAGE->url, 'Đã thêm môn học vào khóa học', null, \core\output\notification::NOTIFY_SUCCESS);
                } else {
                    redirect($PAGE->url, 'Môn học đã có trong khóa học này', null, \core\output\notification::NOTIFY_WARNING);
                }
            }
            break;
    }
}

echo $OUTPUT->header();

echo '<div class="container-fluid">';

// Header với nút actions
echo '<div class="d-flex justify-content-between align-items-center mb-4">';
echo '<h2><i class="fa fa-book"></i> Quản lý môn học</h2>';
echo '<div>';
echo '<a href="' . $CFG->wwwroot . '/local/course_batches/import_subjects.php" class="btn btn-success">';
echo '<i class="fa fa-download"></i> Import từ Moodle';
echo '</a> ';
echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php" class="btn btn-secondary">';
echo '<i class="fa fa-arrow-left"></i> Quay lại';
echo '</a>';
echo '</div>';
echo '</div>';

// Thống kê
$stats = local_course_batches\course_subject_manager::get_dashboard_statistics();

echo '<div class="row mb-4">';
echo '<div class="col-md-3">';
echo '<div class="card bg-primary text-white">';
echo '<div class="card-body text-center">';
echo '<h3>' . $stats['total_subjects'] . '</h3>';
echo '<p><i class="fa fa-book"></i> Tổng môn học</p>';
echo '</div>';
echo '</div>';
echo '</div>';

echo '<div class="col-md-3">';
echo '<div class="card bg-success text-white">';
echo '<div class="card-body text-center">';
echo '<h3>' . $stats['assigned_subjects'] . '</h3>';
echo '<p><i class="fa fa-check"></i> Đã gán khóa học</p>';
echo '</div>';
echo '</div>';
echo '</div>';

echo '<div class="col-md-3">';
echo '<div class="card bg-warning text-white">';
echo '<div class="card-body text-center">';
echo '<h3>' . $stats['unassigned_subjects'] . '</h3>';
echo '<p><i class="fa fa-clock-o"></i> Chưa gán</p>';
echo '</div>';
echo '</div>';
echo '</div>';

echo '<div class="col-md-3">';
echo '<div class="card bg-info text-white">';
echo '<div class="card-body text-center">';
echo '<h3>' . $stats['total_batches'] . '</h3>';
echo '<p><i class="fa fa-graduation-cap"></i> Tổng khóa học</p>';
echo '</div>';
echo '</div>';
echo '</div>';
echo '</div>';

// Tabs
echo '<ul class="nav nav-tabs mb-3" role="tablist">';
echo '<li class="nav-item" role="presentation">';
echo '<button class="nav-link active" data-bs-toggle="tab" data-bs-target="#all-subjects" type="button">Tất cả môn học</button>';
echo '</li>';
echo '<li class="nav-item" role="presentation">';
echo '<button class="nav-link" data-bs-toggle="tab" data-bs-target="#unassigned-subjects" type="button">Môn học chưa gán</button>';
echo '</li>';
echo '</ul>';

echo '<div class="tab-content">';

// Tab 1: Tất cả môn học
echo '<div class="tab-pane fade show active" id="all-subjects">';

$all_subjects = $DB->get_records('local_course_subjects', null, 'last_updated DESC');

if (empty($all_subjects)) {
    echo '<div class="alert alert-info">';
    echo '<i class="fa fa-info-circle"></i> Chưa có môn học nào. ';
    echo '<a href="' . $CFG->wwwroot . '/local/course_batches/import_subjects.php" class="btn btn-sm btn-primary">Import ngay</a>';
    echo '</div>';
} else {
    echo '<div class="table-responsive">';
    echo '<table class="table table-striped table-hover">';
    echo '<thead class="table-dark">';
    echo '<tr>';
    echo '<th>ID</th>';
    echo '<th>Thông tin môn học</th>';
    echo '<th>Thời gian</th>';
    echo '<th>Danh mục</th>';
    echo '<th>Thống kê</th>';
    echo '<th>Trạng thái gán</th>';
    echo '<th>Thao tác</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    
    foreach ($all_subjects as $subject) {
        // Kiểm tra đã gán vào khóa học nào chưa
        $assigned_batch = $DB->get_record_sql(
            "SELECT b.id, b.batch_name, bs.assigned_date, bs.assignment_type
             FROM {local_course_batches} b
             JOIN {local_batch_subjects} bs ON bs.batch_id = b.id
             WHERE bs.subject_id = ?", 
            array($subject->id)
        );
        
        echo '<tr>';
        echo '<td>' . $subject->id . '</td>';
        
        // Thông tin môn học
        echo '<td>';
        echo '<a href="' . $CFG->wwwroot . '/course/view.php?id=' . $subject->moodle_course_id . '" target="_blank">';
        echo '<strong>' . htmlspecialchars($subject->subject_name) . '</strong>';
        echo '</a><br>';
        echo '<small class="text-muted">Mã: ' . htmlspecialchars($subject->subject_code) . '</small>';
        if ($subject->visible) {
            echo ' <span class="badge bg-success">Hiển thị</span>';
        } else {
            echo ' <span class="badge bg-secondary">Ẩn</span>';
        }
        echo '</td>';
        
        // Thời gian
        echo '<td>';
        echo date('d/m/Y', $subject->start_date);
        if ($subject->end_date) {
            echo '<br><small class="text-muted">đến ' . date('d/m/Y', $subject->end_date) . '</small>';
        }
        echo '</td>';
        
        // Danh mục
        echo '<td>' . htmlspecialchars($subject->category_name ?: 'Không có') . '</td>';
        
        // Thống kê
        echo '<td>';
        echo '<span class="badge bg-primary">' . $subject->enrolled_users . ' HV</span><br>';
        echo '<span class="badge bg-info">' . $subject->total_activities . ' HĐ</span>';
        echo '</td>';
        
        // Trạng thái gán
        echo '<td>';
        if ($assigned_batch) {
            echo '<span class="badge bg-success">Đã gán</span><br>';
            echo '<small>' . htmlspecialchars($assigned_batch->batch_name) . '</small><br>';
            echo '<small class="text-muted">' . ucfirst($assigned_batch->assignment_type) . '</small>';
        } else {
            echo '<span class="badge bg-warning">Chưa gán</span>';
        }
        echo '</td>';
        
        // Thao tác
        echo '<td>';
        echo '<div class="btn-group-vertical btn-group-sm">';
        
        // Nút cập nhật
        $update_url = new moodle_url($PAGE->url, array(
            'action' => 'update_subject',
            'subject_id' => $subject->id,
            'sesskey' => sesskey()
        ));
        echo '<a href="' . $update_url . '" class="btn btn-sm btn-warning" title="Cập nhật từ Moodle">';
        echo '<i class="fa fa-refresh"></i>';
        echo '</a>';
        
        // Nút xem chi tiết
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/subject_detail.php?id=' . $subject->id . '" class="btn btn-sm btn-info" title="Xem chi tiết">';
        echo '<i class="fa fa-eye"></i>';
        echo '</a>';
        
        // Nút gán vào khóa học (nếu chưa gán)
        if (!$assigned_batch) {
            echo '<button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#assignModal' . $subject->id . '" title="Gán vào khóa học">';
            echo '<i class="fa fa-plus"></i>';
            echo '</button>';
        }
        
        echo '</div>';
        echo '</td>';
        
        echo '</tr>';
        
        // Modal gán vào khóa học
        if (!$assigned_batch) {
            echo '<div class="modal fade" id="assignModal' . $subject->id . '" tabindex="-1">';
            echo '<div class="modal-dialog">';
            echo '<div class="modal-content">';
            echo '<div class="modal-header">';
            echo '<h5 class="modal-title">Gán môn học vào khóa học</h5>';
            echo '<button type="button" class="btn-close" data-bs-dismiss="modal"></button>';
            echo '</div>';
            echo '<div class="modal-body">';
            echo '<p><strong>Môn học:</strong> ' . htmlspecialchars($subject->subject_name) . '</p>';
            echo '<form method="post">';
            echo '<input type="hidden" name="action" value="add_to_batch">';
            echo '<input type="hidden" name="subject_id" value="' . $subject->id . '">';
            echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
            echo '<div class="mb-3">';
            echo '<label for="batch_id" class="form-label">Chọn khóa học:</label>';
            echo '<select name="batch_id" class="form-select" required>';
            echo '<option value="">-- Chọn khóa học --</option>';
            
            $batches = local_course_batches\course_subject_manager::get_all_course_batches();
            foreach ($batches as $batch) {
                echo '<option value="' . $batch->id . '">';
                echo htmlspecialchars($batch->batch_name) . ' (' . date('d/m/Y', $batch->start_date) . ' - ' . date('d/m/Y', $batch->end_date) . ')';
                echo '</option>';
            }
            
            echo '</select>';
            echo '</div>';
            echo '<button type="submit" class="btn btn-primary">Gán vào khóa học</button>';
            echo '</form>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    }
    
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}

echo '</div>';

// Tab 2: Môn học chưa gán
echo '<div class="tab-pane fade" id="unassigned-subjects">';

$unassigned_subjects = local_course_batches\course_subject_manager::get_unassigned_subjects();

if (empty($unassigned_subjects)) {
    echo '<div class="alert alert-success">';
    echo '<i class="fa fa-check-circle"></i> Tất cả môn học đã được gán vào khóa học.';
    echo '</div>';
} else {
    echo '<div class="alert alert-info">';
    echo '<i class="fa fa-info-circle"></i> Có ' . count($unassigned_subjects) . ' môn học chưa được gán vào khóa học nào.';
    echo '</div>';
    
    echo '<div class="table-responsive">';
    echo '<table class="table table-striped">';
    echo '<thead class="table-dark">';
    echo '<tr>';
    echo '<th>Tên môn học</th>';
    echo '<th>Mã môn học</th>';
    echo '<th>Thời gian</th>';
    echo '<th>Thống kê</th>';
    echo '<th>Thao tác</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    
    foreach ($unassigned_subjects as $subject) {
        echo '<tr>';
        echo '<td>';
        echo '<a href="' . $CFG->wwwroot . '/course/view.php?id=' . $subject->moodle_course_id . '" target="_blank">';
        echo htmlspecialchars($subject->subject_name);
        echo '</a>';
        echo '</td>';
        echo '<td><code>' . htmlspecialchars($subject->subject_code) . '</code></td>';
        echo '<td>' . date('d/m/Y', $subject->start_date);
        if ($subject->end_date) {
            echo ' - ' . date('d/m/Y', $subject->end_date);
        }
        echo '</td>';
        echo '<td>';
        echo $subject->enrolled_users . ' HV, ';
        echo $subject->total_activities . ' HĐ';
        echo '</td>';
        echo '<td>';
        echo '<button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#assignModal' . $subject->id . '">';
        echo '<i class="fa fa-plus"></i> Gán vào khóa học';
        echo '</button>';
        echo '</td>';
        echo '</tr>';
    }
    
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}

echo '</div>';

echo '</div>'; // End tab-content

echo '</div>'; // End container

echo $OUTPUT->footer();