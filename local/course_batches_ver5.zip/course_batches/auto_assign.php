<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Tự động gán môn học vào khóa học dựa trên thời gian
 *
 * @package    local_course_batches
 * @copyright  2025 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/course_subject_manager.php');

require_login();
$context = context_system::instance();
require_capability('local/course_batches:manage', $context);

$batch_id = required_param('batch_id', PARAM_INT);
$confirm = optional_param('confirm', 0, PARAM_INT);

$PAGE->set_url('/local/course_batches/auto_assign.php', array('batch_id' => $batch_id));
$PAGE->set_context($context);
$PAGE->set_title('Tự động gán môn học');
$PAGE->set_heading('Tự động gán môn học');

// Kiểm tra khóa học có tồn tại không
$batch = local_course_batches\course_subject_manager::get_course_batch($batch_id);
if (!$batch) {
    throw new moodle_exception('Không tìm thấy khóa học');
}

echo $OUTPUT->header();

echo '<div class="container-fluid">';

if ($confirm) {
    // Thực hiện tự động gán
    echo '<div class="alert alert-info">';
    echo '<i class="fa fa-spinner fa-spin"></i> Đang thực hiện tự động gán môn học...';
    echo '</div>';
    
    $result = local_course_batches\course_subject_manager::auto_assign_subjects_to_batch($batch_id);
    
    if ($result['success']) {
        echo '<div class="alert alert-success">';
        echo '<i class="fa fa-check-circle"></i> <strong>Hoàn thành!</strong><br>';
        echo 'Đã gán <strong>' . $result['assigned_count'] . '</strong> môn học vào khóa <em>' . htmlspecialchars($batch->batch_name) . '</em><br>';
        if ($result['duplicate_count'] > 0) {
            echo '<small class="text-muted">(' . $result['duplicate_count'] . ' môn học đã được gán trước đó)</small>';
        }
        echo '</div>';
        
        if (!empty($result['assigned_subjects'])) {
            echo '<h5><i class="fa fa-list"></i> Chi tiết môn học đã gán:</h5>';
            echo '<div class="table-responsive">';
            echo '<table class="table table-striped table-sm">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>Môn học</th>';
            echo '<th>Mã môn</th>';
            echo '<th>Thời gian môn học</th>';
            echo '<th>Lý do gán</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            
            foreach ($result['assigned_subjects'] as $subject) {
                echo '<tr>';
                echo '<td><strong>' . htmlspecialchars($subject['name']) . '</strong></td>';
                echo '<td>' . htmlspecialchars($subject['code']) . '</td>';
                echo '<td>' . date('d/m/Y', $subject['start_date']);
                if ($subject['end_date']) {
                    echo ' - ' . date('d/m/Y', $subject['end_date']);
                }
                echo '</td>';
                echo '<td><small class="text-success">Thời gian nằm trong khung khóa học</small></td>';
                echo '</tr>';
            }
            
            echo '</tbody>';
            echo '</table>';
            echo '</div>';
        }
        
        echo '<div class="mt-3">';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php?action=view_subjects&id=' . $batch_id . '" class="btn btn-primary">';
        echo '<i class="fa fa-eye"></i> Xem danh sách môn học trong khóa';
        echo '</a> ';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php" class="btn btn-secondary">';
        echo '<i class="fa fa-arrow-left"></i> Quay lại trang chính';
        echo '</a>';
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-danger">';
        echo '<i class="fa fa-exclamation-triangle"></i> <strong>Lỗi:</strong> ' . htmlspecialchars($result['error']);
        echo '</div>';
        
        echo '<div class="mt-3">';
        echo '<a href="?batch_id=' . $batch_id . '" class="btn btn-primary">Thử lại</a> ';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/new_index.php" class="btn btn-secondary">Quay lại</a>';
        echo '</div>';
    }
    
} else {
    // Hiển thị xác nhận
    echo '<div class="d-flex justify-content-between align-items-center mb-4">';
    echo '<h2><i class="fa fa-magic"></i> Tự động gán môn học vào khóa</h2>';
    echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php?action=view_subjects&id=' . $batch_id . '" class="btn btn-secondary">';
    echo '<i class="fa fa-arrow-left"></i> Quay lại';
    echo '</a>';
    echo '</div>';
    
    // Thông tin khóa học
    echo '<div class="card mb-4">';
    echo '<div class="card-header bg-primary text-white">';
    echo '<h4><i class="fa fa-graduation-cap"></i> ' . htmlspecialchars($batch->batch_name) . '</h4>';
    echo '</div>';
    echo '<div class="card-body">';
    echo '<div class="row">';
    echo '<div class="col-md-6">';
    echo '<strong>Thời gian khóa học:</strong><br>';
    echo '<span class="text-primary">' . date('d/m/Y', $batch->start_date) . ' - ' . date('d/m/Y', $batch->end_date) . '</span>';
    echo '</div>';
    echo '<div class="col-md-6">';
    if (!empty($batch->description)) {
        echo '<strong>Mô tả:</strong><br>' . htmlspecialchars($batch->description);
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Lấy preview môn học sẽ được gán
    $preview = local_course_batches\course_subject_manager::preview_auto_assign($batch_id);
    
    if (empty($preview)) {
        echo '<div class="alert alert-warning">';
        echo '<i class="fa fa-exclamation-triangle"></i> ';
        echo '<strong>Không có môn học nào phù hợp</strong><br>';
        echo 'Không tìm thấy môn học nào có thời gian nằm trong khoảng thời gian của khóa học này.';
        echo '</div>';
        
        echo '<div class="alert alert-info">';
        echo '<i class="fa fa-info-circle"></i> ';
        echo '<strong>Gợi ý:</strong><br>';
        echo '• Kiểm tra lại thời gian khóa học<br>';
        echo '• Đảm bảo đã import đủ môn học từ Moodle<br>';
        echo '• Kiểm tra thời gian các môn học trong hệ thống';
        echo '</div>';
        
        echo '<div class="mt-3">';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/import_subjects.php" class="btn btn-warning">';
        echo '<i class="fa fa-download"></i> Import thêm môn học';
        echo '</a> ';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/subjects.php" class="btn btn-info">';
        echo '<i class="fa fa-book"></i> Xem tất cả môn học';
        echo '</a>';
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-success">';
        echo '<i class="fa fa-check-circle"></i> ';
        echo '<strong>Tìm thấy ' . count($preview) . ' môn học phù hợp</strong><br>';
        echo 'Các môn học sau sẽ được tự động gán vào khóa học dựa trên thời gian:';
        echo '</div>';
        
        echo '<div class="table-responsive">';
        echo '<table class="table table-striped table-hover">';
        echo '<thead class="table-dark">';
        echo '<tr>';
        echo '<th>Môn học</th>';
        echo '<th>Mã môn</th>';
        echo '<th>Thời gian môn học</th>';
        echo '<th>Danh mục</th>';
        echo '<th>Học viên</th>';
        echo '<th>Trạng thái</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($preview as $subject) {
            echo '<tr>';
            echo '<td>';
            echo '<strong>' . htmlspecialchars($subject->subject_name) . '</strong>';
            if (!empty($subject->summary)) {
                $summary = strip_tags($subject->summary);
                if (strlen($summary) > 80) {
                    $summary = substr($summary, 0, 80) . '...';
                }
                echo '<br><small class="text-muted">' . htmlspecialchars($summary) . '</small>';
            }
            echo '</td>';
            echo '<td>' . htmlspecialchars($subject->subject_code) . '</td>';
            echo '<td>';
            echo '<strong>' . date('d/m/Y', $subject->start_date) . '</strong>';
            if ($subject->end_date) {
                echo '<br><small class="text-muted">đến ' . date('d/m/Y', $subject->end_date) . '</small>';
            }
            echo '</td>';
            echo '<td>' . htmlspecialchars($subject->category_name ?: 'Không có') . '</td>';
            echo '<td><span class="badge bg-primary">' . $subject->enrolled_users . '</span></td>';
            echo '<td>';
            if ($subject->visible) {
                echo '<span class="badge bg-success">Hiển thị</span>';
            } else {
                echo '<span class="badge bg-secondary">Ẩn</span>';
            }
            echo '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        
        // Nút xác nhận
        echo '<div class="mt-4 text-center">';
        echo '<div class="alert alert-warning">';
        echo '<i class="fa fa-exclamation-triangle"></i> ';
        echo '<strong>Xác nhận tự động gán</strong><br>';
        echo 'Bạn có chắc chắn muốn gán ' . count($preview) . ' môn học này vào khóa <em>' . htmlspecialchars($batch->batch_name) . '</em>?<br>';
        echo '<small class="text-muted">Các môn học đã được gán trước đó sẽ không bị trùng lặp.</small>';
        echo '</div>';
        
        echo '<a href="?batch_id=' . $batch_id . '&confirm=1" class="btn btn-success btn-lg me-3">';
        echo '<i class="fa fa-check"></i> Xác nhận gán ' . count($preview) . ' môn học';
        echo '</a>';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php?action=view_subjects&id=' . $batch_id . '" class="btn btn-secondary btn-lg">';
        echo '<i class="fa fa-times"></i> Hủy bỏ';
        echo '</a>';
        echo '</div>';
    }
}

echo '</div>'; // End container

echo $OUTPUT->footer();