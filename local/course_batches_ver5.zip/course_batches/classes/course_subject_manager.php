<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Course Batch Manager - Quản lý khóa học và môn học
 *
 * @package    local_course_batches
 * @copyright  2025 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_course_batches;

defined('MOODLE_INTERNAL') || die();

/**
 * Class để quản lý khóa học và môn học
 */
class course_subject_manager {
    
    /**
     * Tạo khóa học mới
     * @param string $batch_name Tên khóa học
     * @param int $start_date Ngày bắt đầu
     * @param int $end_date Ngày kết thúc
     * @param string $description Mô tả
     * @return int ID của khóa học vừa tạo
     */
    public static function create_course_batch($batch_name, $start_date, $end_date, $description = '') {
        global $DB;
        
        $record = new \stdClass();
        $record->batch_name = $batch_name;
        $record->start_date = $start_date;
        $record->end_date = $end_date;
        $record->description = $description;
        $record->status = 1;
        $record->created_date = time();
        
        $batch_id = $DB->insert_record('local_course_batches', $record);
        
        // Tự động gán môn học theo khoảng thời gian
        self::auto_assign_subjects_to_batch($batch_id);
        
        return $batch_id;
    }
    
    /**
     * Lấy danh sách tất cả khóa học
     * @return array
     */
    public static function get_all_course_batches() {
        global $DB;
        return $DB->get_records('local_course_batches', null, 'created_date DESC');
    }
    
    /**
     * Lấy thông tin một khóa học
     * @param int $batch_id
     * @return object|false
     */
    public static function get_course_batch($batch_id) {
        global $DB;
        return $DB->get_record('local_course_batches', array('id' => $batch_id));
    }
    
    /**
     * Import tất cả môn học từ Moodle courses
     * @param bool $clear_existing Có xóa dữ liệu cũ không
     * @return int Số môn học đã import
     */
    public static function import_subjects_from_moodle($clear_existing = false) {
        global $DB;
        
        if ($clear_existing) {
            // Xóa tất cả dữ liệu cũ
            $DB->delete_records('local_batch_subjects');
            $DB->delete_records('local_course_subjects');
        }
        
        // Lấy tất cả courses từ Moodle (trừ site course)
        $sql = "SELECT c.id, c.fullname, c.shortname, c.startdate, c.enddate, 
                       c.summary, c.visible, c.category,
                       cat.name as category_name
                FROM {course} c
                LEFT JOIN {course_categories} cat ON cat.id = c.category
                WHERE c.id > 1
                ORDER BY c.startdate DESC, c.fullname";
        
        $courses = $DB->get_records_sql($sql);
        $imported_count = 0;
        
        foreach ($courses as $course) {
            // Kiểm tra xem đã import chưa
            if ($DB->record_exists('local_course_subjects', array('moodle_course_id' => $course->id))) {
                continue; // Đã tồn tại, bỏ qua
            }
            
            // Tạo record môn học mới
            $subject = new \stdClass();
            $subject->moodle_course_id = $course->id;
            $subject->subject_name = $course->fullname;
            $subject->subject_code = $course->shortname;
            $subject->start_date = $course->startdate;
            $subject->end_date = $course->enddate ?: null;
            $subject->category_name = $course->category_name;
            $subject->summary = $course->summary;
            $subject->visible = $course->visible;
            $subject->imported_date = time();
            $subject->last_updated = time();
            
            // Lấy thống kê học viên và hoạt động
            $stats = self::get_course_statistics($course->id);
            $subject->enrolled_users = $stats['enrolled_users'];
            $subject->total_activities = $stats['total_activities'];
            
            $DB->insert_record('local_course_subjects', $subject);
            $imported_count++;
        }
        
        return $imported_count;
    }
    
    /**
     * Lấy thống kê của một course
     * @param int $course_id
     * @return array
     */
    private static function get_course_statistics($course_id) {
        global $DB;
        
        try {
            // Đếm số học viên
            $enrolled_sql = "SELECT COUNT(DISTINCT u.id) as count
                           FROM {user_enrolments} ue
                           JOIN {enrol} e ON e.id = ue.enrolid
                           JOIN {user} u ON u.id = ue.userid
                           WHERE e.courseid = ? AND ue.status = 0 AND u.deleted = 0";
            $enrolled_result = $DB->get_record_sql($enrolled_sql, array($course_id));
            $enrolled_users = $enrolled_result ? $enrolled_result->count : 0;
            
            // Đếm số hoạt động
            $activities_sql = "SELECT COUNT(*) as count
                             FROM {course_modules} cm
                             WHERE cm.course = ? AND cm.visible = 1";
            $activities_result = $DB->get_record_sql($activities_sql, array($course_id));
            $total_activities = $activities_result ? $activities_result->count : 0;
            
            return array(
                'enrolled_users' => $enrolled_users,
                'total_activities' => $total_activities
            );
        } catch (\Exception $e) {
            return array(
                'enrolled_users' => 0,
                'total_activities' => 0
            );
        }
    }
    
    /**
     * Tự động gán môn học vào khóa học theo khoảng thời gian
     * @param int $batch_id ID khóa học
     * @return int Số môn học đã gán
     */
    public static function auto_assign_subjects_to_batch($batch_id) {
        global $DB;
        
        $batch = self::get_course_batch($batch_id);
        if (!$batch) {
            return 0;
        }
        
        // Tìm các môn học có thời gian nằm trong khoảng thời gian của khóa học
        $sql = "SELECT s.*
                FROM {local_course_subjects} s
                WHERE s.start_date >= ? 
                AND (s.end_date IS NULL OR s.end_date <= ?)
                AND s.visible = 1
                AND NOT EXISTS (
                    SELECT 1 FROM {local_batch_subjects} bs 
                    WHERE bs.subject_id = s.id AND bs.batch_id = ?
                )
                ORDER BY s.start_date, s.subject_name";
        
        $subjects = $DB->get_records_sql($sql, array($batch->start_date, $batch->end_date, $batch_id));
        
        $assigned_count = 0;
        foreach ($subjects as $subject) {
            $record = new \stdClass();
            $record->batch_id = $batch_id;
            $record->subject_id = $subject->id;
            $record->assigned_date = time();
            $record->assignment_type = 'auto';
            
            if ($DB->insert_record('local_batch_subjects', $record)) {
                $assigned_count++;
            }
        }
        
        return $assigned_count;
    }
    
    /**
     * Lấy danh sách môn học trong một khóa học
     * @param int $batch_id
     * @return array
     */
    public static function get_subjects_in_batch($batch_id) {
        global $DB;
        
        $sql = "SELECT s.*, bs.assigned_date, bs.assignment_type
                FROM {local_course_subjects} s
                JOIN {local_batch_subjects} bs ON bs.subject_id = s.id
                WHERE bs.batch_id = ?
                ORDER BY s.start_date, s.subject_name";
        
        return $DB->get_records_sql($sql, array($batch_id));
    }
    
    /**
     * Lấy danh sách môn học chưa được gán vào khóa học nào
     * @return array
     */
    public static function get_unassigned_subjects() {
        global $DB;
        
        $sql = "SELECT s.*
                FROM {local_course_subjects} s
                WHERE s.visible = 1
                AND NOT EXISTS (
                    SELECT 1 FROM {local_batch_subjects} bs 
                    WHERE bs.subject_id = s.id
                )
                ORDER BY s.start_date DESC, s.subject_name";
        
        return $DB->get_records_sql($sql);
    }
    
    /**
     * Thêm môn học vào khóa học (thủ công)
     * @param int $batch_id
     * @param int $subject_id
     * @return bool
     */
    public static function add_subject_to_batch($batch_id, $subject_id) {
        global $DB;
        
        // Kiểm tra đã tồn tại chưa
        if ($DB->record_exists('local_batch_subjects', array('batch_id' => $batch_id, 'subject_id' => $subject_id))) {
            return false;
        }
        
        $record = new \stdClass();
        $record->batch_id = $batch_id;
        $record->subject_id = $subject_id;
        $record->assigned_date = time();
        $record->assignment_type = 'manual';
        
        return $DB->insert_record('local_batch_subjects', $record);
    }
    
    /**
     * Xóa môn học khỏi khóa học
     * @param int $batch_id
     * @param int $subject_id
     * @return bool
     */
    public static function remove_subject_from_batch($batch_id, $subject_id) {
        global $DB;
        return $DB->delete_records('local_batch_subjects', array('batch_id' => $batch_id, 'subject_id' => $subject_id));
    }
    
    /**
     * Lấy thông tin cơ bản của một môn học
     * @param int $subject_id
     * @return object|false
     */
    public static function get_subject($subject_id) {
        global $DB;
        return $DB->get_record('local_course_subjects', array('id' => $subject_id));
    }

    /**
     * Lấy chi tiết một môn học
     * @param int $subject_id
     * @return object|false
     */
    public static function get_subject_details($subject_id) {
        global $DB;
        
        $subject = $DB->get_record('local_course_subjects', array('id' => $subject_id));
        if (!$subject) {
            return false;
        }
        
        // Lấy thêm thông tin chi tiết từ Moodle course
        $course = $DB->get_record('course', array('id' => $subject->moodle_course_id));
        if ($course) {
            $subject->moodle_course = $course;
            
            // Lấy thống kê cập nhật
            $stats = self::get_course_statistics($subject->moodle_course_id);
            $subject->current_enrolled_users = $stats['enrolled_users'];
            $subject->current_total_activities = $stats['total_activities'];
        }
        
        return $subject;
    }
    
    /**
     * Cập nhật thông tin một môn học từ Moodle
     * @param int $subject_id
     * @return bool
     */
    public static function update_subject_from_moodle($subject_id) {
        global $DB;
        
        $subject = $DB->get_record('local_course_subjects', array('id' => $subject_id));
        if (!$subject) {
            return false;
        }
        
        $course = $DB->get_record('course', array('id' => $subject->moodle_course_id));
        if (!$course) {
            return false;
        }
        
        // Cập nhật thông tin
        $subject->subject_name = $course->fullname;
        $subject->subject_code = $course->shortname;
        $subject->start_date = $course->startdate;
        $subject->end_date = $course->enddate ?: null;
        $subject->summary = $course->summary;
        $subject->visible = $course->visible;
        $subject->last_updated = time();
        
        // Cập nhật thống kê
        $stats = self::get_course_statistics($course->id);
        $subject->enrolled_users = $stats['enrolled_users'];
        $subject->total_activities = $stats['total_activities'];
        
        return $DB->update_record('local_course_subjects', $subject);
    }
    
    /**
     * Preview môn học sẽ được tự động gán vào khóa học
     *
     * @param int $batch_id ID của khóa học
     * @return array Danh sách môn học sẽ được gán
     */
    public static function preview_auto_assign($batch_id) {
        global $DB;
        
        try {
            // Lấy thông tin khóa học
            $batch = self::get_course_batch($batch_id);
            if (!$batch) {
                return array();
            }
            
            // Tìm môn học có thời gian nằm trong khoảng thời gian khóa học
            $sql = "SELECT cs.*, cc.name as category_name
                    FROM {local_course_subjects} cs
                    LEFT JOIN {course_categories} cc ON cs.category_id = cc.id
                    WHERE cs.start_date >= :batch_start 
                    AND cs.start_date <= :batch_end
                    AND cs.id NOT IN (
                        SELECT bs.subject_id 
                        FROM {local_batch_subjects} bs 
                        WHERE bs.batch_id = :batch_id
                    )
                    ORDER BY cs.start_date ASC";
            
            $params = array(
                'batch_start' => $batch->start_date,
                'batch_end' => $batch->end_date,
                'batch_id' => $batch_id
            );
            
            return $DB->get_records_sql($sql, $params);
            
        } catch (Exception $e) {
            return array();
        }
    }

    /**
     * Lấy thống kê tổng quan
     * @return array
     */
    public static function get_dashboard_statistics() {
        global $DB;
        
        $stats = array();
        
        // Tổng số khóa học
        $stats['total_batches'] = $DB->count_records('local_course_batches');
        
        // Tổng số môn học
        $stats['total_subjects'] = $DB->count_records('local_course_subjects');
        
        // Môn học đã gán
        $stats['assigned_subjects'] = $DB->count_records('local_batch_subjects');
        
        // Môn học chưa gán
        $stats['unassigned_subjects'] = $stats['total_subjects'] - $stats['assigned_subjects'];
        
        // Khóa học đang hoạt động
        $stats['active_batches'] = $DB->count_records('local_course_batches', array('status' => 1));
        
        return $stats;
    }
}

// Giữ lại class cũ để tương thích
class batch_manager extends course_subject_manager {
    
    // Alias methods để tương thích với code cũ
    public static function create_batch($batch_name, $start_date, $end_date, $description = '') {
        return self::create_course_batch($batch_name, $start_date, $end_date, $description);
    }
    
    public static function get_all_batches() {
        return self::get_all_course_batches();
    }
    
    public static function get_batch($batch_id) {
        return self::get_course_batch($batch_id);
    }
    
    public static function get_courses_in_batch($batch_id) {
        return self::get_subjects_in_batch($batch_id);
    }
    
    public static function auto_assign_courses_by_date_range($batch_id, $start_date, $end_date) {
        return self::auto_assign_subjects_to_batch($batch_id);
    }
}