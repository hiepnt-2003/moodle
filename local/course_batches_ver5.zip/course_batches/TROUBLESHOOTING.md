# Hướng dẫn khắc phục vấn đề "Không hiển thị thông tin chi tiết khóa học"

## Vấn đề hiện tại
Khi click "Xem khóa học" trong plugin Course Batches, không hiển thị thông tin chi tiết về khóa học.

## Các bước khắc phục

### Bước 1: Kiểm tra plugin đã được cài đặt chưa
1. Truy cập: `http://your-moodle-site/admin/index.php`
2. Kiểm tra plugin `local_course_batches` có trong danh sách plugins
3. Nếu chưa có, chạy upgrade database

### Bước 2: Tạo dữ liệu mẫu để test
1. Truy cập: `http://your-moodle-site/local/course_batches/setup_sample_data.php`
2. Script này sẽ:
   - Tạo 3 đợt mở môn mẫu
   - Tự động gán khóa học vào các đợt theo khoảng thời gian
   - Hiển thị thống kê

### Bước 3: Test với trang đơn giản
1. Truy cập: `http://your-moodle-site/local/course_batches/simple_test.php`
2. Trang này sẽ hiển thị:
   - Danh sách tất cả đợt mở môn
   - Chi tiết khóa học trong từng đợt
   - Thông tin học viên và hoạt động

### Bước 4: Debug dữ liệu
1. Truy cập: `http://your-moodle-site/local/course_batches/debug.php`
2. Kiểm tra:
   - Cấu trúc database tables
   - Dữ liệu trong các bảng
   - Output của các method

### Bước 5: Kiểm tra permissions
Đảm bảo user có quyền:
- `local/course_batches:view`
- `local/course_batches:manage`

## Các file đã được cải tiến

### 1. classes/batch_manager.php
- ✅ Enhanced `get_courses_in_batch()` với thông tin chi tiết
- ✅ Thêm error handling với try-catch
- ✅ Thêm các method `get_course_details()` và `get_course_teachers()`

### 2. index.php
- ✅ Cải tiến bảng hiển thị với 8 cột thông tin
- ✅ Hiển thị thống kê học viên và hoạt động
- ✅ Thêm links xem chi tiết khóa học

### 3. course_detail.php (mới)
- ✅ Trang chi tiết khóa học hoàn chỉnh
- ✅ Hiển thị thông tin đầy đủ về khóa học
- ✅ Danh sách giảng viên
- ✅ Thống kê chi tiết

### 4. manage_courses.php
- ✅ Cải tiến giao diện quản lý khóa học
- ✅ Hiển thị thông tin chi tiết hơn

## Troubleshooting

### Vấn đề 1: "html_writer not found"
- **Nguyên nhân**: Thiếu import Moodle libraries
- **Giải pháp**: Đã tạo file `simple_test.php` không dùng html_writer

### Vấn đề 2: "Không có dữ liệu"
- **Nguyên nhân**: Chưa có đợt mở môn hoặc khóa học
- **Giải pháp**: Chạy `setup_sample_data.php` để tạo dữ liệu mẫu

### Vấn đề 3: "Permission denied"
- **Nguyên nhân**: User không có quyền truy cập
- **Giải pháp**: Cấp quyền hoặc login bằng admin

### Vấn đề 4: "Database error"
- **Nguyên nhân**: Bảng database chưa được tạo
- **Giải pháp**: Chạy upgrade database từ admin panel

## Test Cases

### Test Case 1: Hiển thị danh sách đợt
```
URL: /local/course_batches/simple_test.php
Expected: Hiển thị bảng với các đợt mở môn
```

### Test Case 2: Hiển thị khóa học trong đợt
```
URL: /local/course_batches/simple_test.php?id=1
Expected: Hiển thị bảng khóa học với thông tin chi tiết
```

### Test Case 3: Chi tiết khóa học
```
URL: /local/course_batches/course_detail.php?id=2&batch_id=1
Expected: Trang chi tiết đầy đủ về khóa học
```

## Thông tin kỹ thuật

### Database Tables
1. `local_course_batches`: Lưu thông tin đợt mở môn
2. `local_course_batch_courses`: Liên kết khóa học với đợt

### Key Methods
1. `get_courses_in_batch($batch_id)`: Lấy danh sách khóa học với thông tin chi tiết
2. `get_course_details($course_id)`: Lấy thông tin chi tiết một khóa học
3. `get_course_teachers($course_id)`: Lấy danh sách giảng viên

### Performance Notes
- Các query đã được tối ưu với LEFT JOIN
- Sử dụng try-catch để handle errors
- Lazy loading cho các thông tin chi tiết

## Liên hệ Support
Nếu vẫn có vấn đề, vui lòng cung cấp:
1. URL của trang bị lỗi
2. Screenshot lỗi
3. Output của debug.php
4. Phiên bản Moodle đang sử dụng