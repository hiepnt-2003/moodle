<?php
// Debug script để kiểm tra dữ liệu
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/batch_manager.php');

require_login();

// Test lấy một batch cụ thể
$batch_id = optional_param('batch_id', 1, PARAM_INT);

echo "<h2>Debug Course Batches Plugin</h2>";

// 1. Kiểm tra danh sách batches
echo "<h3>1. Danh sách đợt mở môn:</h3>";
$batches = local_course_batches\batch_manager::get_all_batches();
echo "<pre>";
print_r($batches);
echo "</pre>";

// 2. Kiểm tra khóa học trong một batch
if (!empty($batches)) {
    $first_batch = reset($batches);
    $batch_id = $first_batch->id;
    
    echo "<h3>2. Khóa học trong đợt ID {$batch_id}:</h3>";
    $courses = local_course_batches\batch_manager::get_courses_in_batch($batch_id);
    echo "<pre>";
    print_r($courses);
    echo "</pre>";
    
    if (!empty($courses)) {
        $course = reset($courses);
        echo "<h3>3. Chi tiết khóa học đầu tiên:</h3>";
        echo "<ul>";
        echo "<li>ID: " . $course->id . "</li>";
        echo "<li>Tên: " . $course->fullname . "</li>";
        echo "<li>Học viên: " . ($course->enrolled_users ?: '0') . "</li>";
        echo "<li>Hoạt động: " . ($course->total_activities ?: '0') . "</li>";
        echo "<li>Danh mục: " . ($course->category_name ?: 'Không xác định') . "</li>";
        echo "</ul>";
    } else {
        echo "<p>Không có khóa học nào trong đợt này.</p>";
    }
} else {
    echo "<p>Không có đợt mở môn nào.</p>";
}

// 3. Kiểm tra database tables
echo "<h3>4. Kiểm tra bảng database:</h3>";
$batch_count = $DB->count_records('local_course_batches');
$course_batch_count = $DB->count_records('local_course_batch_courses');
echo "<ul>";
echo "<li>Số đợt mở môn: " . $batch_count . "</li>";
echo "<li>Số liên kết khóa học-đợt: " . $course_batch_count . "</li>";
echo "</ul>";

// 4. Kiểm tra cấu trúc bảng
echo "<h3>5. Cấu trúc bảng local_course_batches:</h3>";
$columns = $DB->get_columns('local_course_batches');
echo "<pre>";
foreach ($columns as $column) {
    echo $column->name . " - " . $column->type . "\n";
}
echo "</pre>";

echo "<h3>6. Cấu trúc bảng local_course_batch_courses:</h3>";
$columns = $DB->get_columns('local_course_batch_courses');
echo "<pre>";
foreach ($columns as $column) {
    echo $column->name . " - " . $column->type . "\n";
}
echo "</pre>";