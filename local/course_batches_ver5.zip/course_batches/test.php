<?php
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/batch_manager.php');

require_login();
$context = context_system::instance();
require_capability('local/course_batches:view', $context);

$PAGE->set_url('/local/course_batches/test.php');
$PAGE->set_context($context);
$PAGE->set_title('Test Course Batches');
$PAGE->set_heading('Test Course Batches');

echo $OUTPUT->header();

echo '<h2>Test Thông tin chi tiết khóa học</h2>';

// Lấy tham số
$batch_id = optional_param('id', 0, PARAM_INT);

if ($batch_id > 0) {
    echo '<h3>Khóa học trong đợt ID: ' . $batch_id . '</h3>';
    
    // Lấy thông tin đợt
    $batch = local_course_batches\batch_manager::get_batch($batch_id);
    if ($batch) {
        echo '<div class="alert alert-info">';
        echo '<strong>Tên đợt:</strong> ' . $batch->batch_name . '<br>';
        echo '<strong>Thời gian:</strong> ' . date('d/m/Y', $batch->start_date) . ' - ' . date('d/m/Y', $batch->end_date) . '<br>';
        echo '</div>';
        
        // Lấy danh sách khóa học
        $courses = local_course_batches\batch_manager::get_courses_in_batch($batch_id);
        
        if (!empty($courses)) {
            echo '<table class="table table-striped">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>ID</th>';
            echo '<th>Tên khóa học</th>';
            echo '<th>Mã khóa học</th>';
            echo '<th>Danh mục</th>';
            echo '<th>Học viên</th>';
            echo '<th>Hoạt động</th>';
            echo '<th>Chi tiết</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            
            foreach ($courses as $course) {
                echo '<tr>';
                echo '<td>' . $course->id . '</td>';
                echo '<td><a href="' . $CFG->wwwroot . '/course/view.php?id=' . $course->id . '" target="_blank">' . $course->fullname . '</a></td>';
                echo '<td>' . $course->shortname . '</td>';
                echo '<td>' . ($course->category_name ?: 'Không xác định') . '</td>';
                echo '<td>';
                echo '<strong>' . ($course->enrolled_users ?: '0') . '</strong> học viên<br>';
                if (!empty($course->active_users)) {
                    echo '<small class="text-success">' . $course->active_users . ' đang hoạt động</small>';
                }
                echo '</td>';
                echo '<td>';
                echo '<strong>' . ($course->total_activities ?: '0') . '</strong> hoạt động<br>';
                $details = array();
                if (!empty($course->assignments)) $details[] = $course->assignments . ' bài tập';
                if (!empty($course->quizzes)) $details[] = $course->quizzes . ' kiểm tra';
                if (!empty($course->forums)) $details[] = $course->forums . ' diễn đàn';
                if (!empty($course->resources)) $details[] = $course->resources . ' tài nguyên';
                if (!empty($details)) {
                    echo '<small class="text-muted">' . implode(', ', $details) . '</small>';
                }
                echo '</td>';
                echo '<td>';
                echo '<a href="/local/course_batches/course_detail.php?id=' . $course->id . '&batch_id=' . $batch_id . '" class="btn btn-sm btn-info">Chi tiết</a>';
                echo '</td>';
                echo '</tr>';
            }
            
            echo '</tbody>';
            echo '</table>';
            
            echo '<div class="alert alert-success">';
            echo '<strong>Tổng kết:</strong> ' . count($courses) . ' khóa học trong đợt này';
            echo '</div>';
        } else {
            echo '<div class="alert alert-warning">Không có khóa học nào trong đợt này.</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Không tìm thấy đợt mở môn.</div>';
    }
} else {
    // Hiển thị danh sách tất cả đợt
    echo '<h3>Danh sách tất cả đợt mở môn</h3>';
    $batches = local_course_batches\batch_manager::get_all_batches();
    
    if (!empty($batches)) {
        echo '<table class="table table-striped">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>Tên đợt</th>';
        echo '<th>Thời gian</th>';
        echo '<th>Số khóa học</th>';
        echo '<th>Thao tác</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($batches as $batch) {
            $course_count = count(local_course_batches\batch_manager::get_courses_in_batch($batch->id));
            
            echo '<tr>';
            echo '<td>' . $batch->id . '</td>';
            echo '<td>' . $batch->batch_name . '</td>';
            echo '<td>' . date('d/m/Y', $batch->start_date) . ' - ' . date('d/m/Y', $batch->end_date) . '</td>';
            echo '<td>' . $course_count . ' khóa học</td>';
            echo '<td>';
            echo '<a href="?id=' . $batch->id . '" class="btn btn-sm btn-primary">Xem khóa học</a>';
            echo '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<div class="alert alert-warning">Chưa có đợt mở môn nào.</div>';
    }
}

echo $OUTPUT->footer();