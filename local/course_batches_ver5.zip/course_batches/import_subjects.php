<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Script import môn học từ Moodle courses
 *
 * @package    local_course_batches
 * @copyright  2025 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/course_subject_manager.php');

require_login();

if (!is_siteadmin()) {
    die('Chỉ admin mới có thể chạy script này.');
}

// Lấy tham số
$clear_data = optional_param('clear', 0, PARAM_INT);
$confirm = optional_param('confirm', 0, PARAM_INT);

echo $OUTPUT->header();

echo '<div class="container-fluid">';
echo '<h2><i class="fa fa-download"></i> Import Môn Học Từ Moodle</h2>';

if ($confirm && confirm_sesskey()) {
    echo '<div class="alert alert-info">';
    echo '<i class="fa fa-spinner fa-spin"></i> Đang import dữ liệu...';
    echo '</div>';
    
    $start_time = microtime(true);
    
    try {
        // Import dữ liệu
        $imported_count = local_course_batches\course_subject_manager::import_subjects_from_moodle($clear_data == 1);
        
        $end_time = microtime(true);
        $execution_time = round($end_time - $start_time, 2);
        
        echo '<div class="alert alert-success">';
        echo '<i class="fa fa-check-circle"></i> ';
        echo '<strong>Import hoàn thành!</strong><br>';
        echo "Đã import {$imported_count} môn học trong {$execution_time} giây.";
        echo '</div>';
        
        // Hiển thị thống kê
        $stats = local_course_batches\course_subject_manager::get_dashboard_statistics();
        
        echo '<div class="row mt-4">';
        echo '<div class="col-md-3">';
        echo '<div class="card bg-primary text-white">';
        echo '<div class="card-body text-center">';
        echo '<h3>' . $stats['total_subjects'] . '</h3>';
        echo '<p>Tổng môn học</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="col-md-3">';
        echo '<div class="card bg-success text-white">';
        echo '<div class="card-body text-center">';
        echo '<h3>' . $stats['assigned_subjects'] . '</h3>';
        echo '<p>Môn học đã gán</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="col-md-3">';
        echo '<div class="card bg-warning text-white">';
        echo '<div class="card-body text-center">';
        echo '<h3>' . $stats['unassigned_subjects'] . '</h3>';
        echo '<p>Môn học chưa gán</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="col-md-3">';
        echo '<div class="card bg-info text-white">';
        echo '<div class="card-body text-center">';
        echo '<h3>' . $stats['total_batches'] . '</h3>';
        echo '<p>Tổng khóa học</p>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
    } catch (Exception $e) {
        echo '<div class="alert alert-danger">';
        echo '<i class="fa fa-times-circle"></i> ';
        echo '<strong>Lỗi:</strong> ' . $e->getMessage();
        echo '</div>';
    }
    
    echo '<div class="mt-4">';
    echo '<a href="' . $CFG->wwwroot . '/local/course_batches/subjects.php" class="btn btn-primary">Xem danh sách môn học</a> ';
    echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php" class="btn btn-secondary">Quay lại trang chính</a>';
    echo '</div>';
    
} else {
    // Hiển thị form xác nhận
    echo '<div class="alert alert-warning">';
    echo '<i class="fa fa-exclamation-triangle"></i> ';
    echo '<strong>Cảnh báo:</strong> Script này sẽ import tất cả courses từ Moodle vào bảng môn học.';
    echo '</div>';
    
    // Thống kê hiện tại
    echo '<h4>Thống kê hiện tại:</h4>';
    
    $current_subjects = $DB->count_records('local_course_subjects');
    $total_courses = $DB->count_records('course') - 1; // Trừ site course
    $current_batches = $DB->count_records('local_course_batches');
    
    echo '<div class="row">';
    echo '<div class="col-md-4">';
    echo '<div class="card">';
    echo '<div class="card-body text-center">';
    echo '<h3 class="text-primary">' . $current_subjects . '</h3>';
    echo '<p>Môn học hiện tại</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="col-md-4">';
    echo '<div class="card">';
    echo '<div class="card-body text-center">';
    echo '<h3 class="text-success">' . $total_courses . '</h3>';
    echo '<p>Courses trong Moodle</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="col-md-4">';
    echo '<div class="card">';
    echo '<div class="card-body text-center">';
    echo '<h3 class="text-info">' . $current_batches . '</h3>';
    echo '<p>Khóa học hiện tại</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Form options
    echo '<form method="post" class="mt-4">';
    echo '<input type="hidden" name="sesskey" value="' . sesskey() . '">';
    echo '<input type="hidden" name="confirm" value="1">';
    
    echo '<div class="form-group">';
    echo '<div class="form-check">';
    echo '<input class="form-check-input" type="checkbox" name="clear" value="1" id="clear_data">';
    echo '<label class="form-check-label text-danger" for="clear_data">';
    echo '<strong>Xóa tất cả dữ liệu môn học cũ trước khi import</strong>';
    echo '</label>';
    echo '<small class="form-text text-muted">Cảnh báo: Điều này sẽ xóa tất cả môn học và liên kết hiện có!</small>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="form-group mt-3">';
    echo '<button type="submit" class="btn btn-primary btn-lg">';
    echo '<i class="fa fa-download"></i> Bắt đầu Import';
    echo '</button> ';
    echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php" class="btn btn-secondary">Hủy</a>';
    echo '</div>';
    
    echo '</form>';
    
    // Hiển thị mẫu dữ liệu sẽ import
    echo '<h4 class="mt-4">Mẫu dữ liệu sẽ import (5 courses đầu tiên):</h4>';
    
    $sample_courses = $DB->get_records_sql(
        "SELECT c.id, c.fullname, c.shortname, c.startdate, c.enddate, 
                c.visible, cat.name as category_name
         FROM {course} c
         LEFT JOIN {course_categories} cat ON cat.id = c.category
         WHERE c.id > 1
         ORDER BY c.startdate DESC
         LIMIT 5"
    );
    
    if ($sample_courses) {
        echo '<div class="table-responsive">';
        echo '<table class="table table-striped table-bordered">';
        echo '<thead class="table-dark">';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>Tên môn học</th>';
        echo '<th>Mã môn học</th>';
        echo '<th>Ngày bắt đầu</th>';
        echo '<th>Ngày kết thúc</th>';
        echo '<th>Danh mục</th>';
        echo '<th>Trạng thái</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($sample_courses as $course) {
            echo '<tr>';
            echo '<td>' . $course->id . '</td>';
            echo '<td>' . htmlspecialchars($course->fullname) . '</td>';
            echo '<td><code>' . htmlspecialchars($course->shortname) . '</code></td>';
            echo '<td>' . date('d/m/Y', $course->startdate) . '</td>';
            echo '<td>' . ($course->enddate ? date('d/m/Y', $course->enddate) : 'Không có') . '</td>';
            echo '<td>' . htmlspecialchars($course->category_name ?: 'Không có') . '</td>';
            echo '<td>';
            if ($course->visible) {
                echo '<span class="badge bg-success">Hiển thị</span>';
            } else {
                echo '<span class="badge bg-secondary">Ẩn</span>';
            }
            echo '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    }
}

echo '</div>';

echo $OUTPUT->footer();