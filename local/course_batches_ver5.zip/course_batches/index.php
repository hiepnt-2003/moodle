<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Trang chính - Hệ thống khóa học và môn học
 *
 * @package    local_course_batches
 * @copyright  2025 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/course_subject_manager.php');

require_login();
$context = context_system::instance();
require_capability('local/course_batches:view', $context);

$PAGE->set_url('/local/course_batches/index.php');
$PAGE->set_context($context);
$PAGE->set_title('Hệ thống khóa học - môn học');
$PAGE->set_heading('Hệ thống khóa học - môn học');

// Lấy tham số
$action = optional_param('action', '', PARAM_ALPHA);
$batch_id = optional_param('id', 0, PARAM_INT);

echo $OUTPUT->header();

echo '<div class="container-fluid">';

// Header
echo '<div class="d-flex justify-content-between align-items-center mb-4">';
echo '<h2><i class="fa fa-graduation-cap"></i> Hệ thống quản lý khóa học - môn học</h2>';
echo '<div>';
echo '<a href="' . $CFG->wwwroot . '/local/course_batches/manage.php" class="btn btn-success">';
echo '<i class="fa fa-plus"></i> Tạo khóa học mới';
echo '</a> ';
echo '<a href="' . $CFG->wwwroot . '/local/course_batches/subjects.php" class="btn btn-primary">';
echo '<i class="fa fa-book"></i> Quản lý môn học';
echo '</a> ';
echo '<a href="' . $CFG->wwwroot . '/local/course_batches/import_subjects.php" class="btn btn-warning">';
echo '<i class="fa fa-download"></i> Import môn học';
echo '</a>';
echo '</div>';
echo '</div>';

if ($action == 'view_subjects' && $batch_id > 0) {
    // Hiển thị môn học trong khóa học
    $batch = local_course_batches\course_subject_manager::get_course_batch($batch_id);
    if (!$batch) {
        echo '<div class="alert alert-danger">Không tìm thấy khóa học.</div>';
    } else {
        echo '<div class="mb-3">';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php" class="btn btn-secondary">';
        echo '<i class="fa fa-arrow-left"></i> Quay lại danh sách khóa học';
        echo '</a>';
        echo '</div>';
        
        // Thông tin khóa học
        echo '<div class="card mb-4">';
        echo '<div class="card-header bg-primary text-white">';
        echo '<h4><i class="fa fa-graduation-cap"></i> ' . htmlspecialchars($batch->batch_name) . '</h4>';
        echo '</div>';
        echo '<div class="card-body">';
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<strong>Thời gian khóa học:</strong><br>';
        echo date('d/m/Y', $batch->start_date) . ' - ' . date('d/m/Y', $batch->end_date);
        echo '</div>';
        echo '<div class="col-md-6">';
        if (!empty($batch->description)) {
            echo '<strong>Mô tả:</strong><br>' . htmlspecialchars($batch->description);
        }
        echo '</div>';
        echo '</div>';
        
        // Nút tự động gán môn học
        echo '<div class="mt-3">';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/auto_assign.php?batch_id=' . $batch->id . '" class="btn btn-success">';
        echo '<i class="fa fa-magic"></i> Tự động gán môn học theo thời gian';
        echo '</a>';
        echo '</div>';
        
        echo '</div>';
        echo '</div>';
        
        // Danh sách môn học trong khóa học
        $subjects = local_course_batches\course_subject_manager::get_subjects_in_batch($batch_id);
        
        if (empty($subjects)) {
            echo '<div class="alert alert-warning">';
            echo '<i class="fa fa-exclamation-triangle"></i> ';
            echo 'Chưa có môn học nào trong khóa học này. ';
            echo '<a href="' . $CFG->wwwroot . '/local/course_batches/auto_assign.php?batch_id=' . $batch->id . '" class="btn btn-sm btn-primary">Tự động gán ngay</a>';
            echo '</div>';
        } else {
            echo '<h4><i class="fa fa-book"></i> Danh sách môn học trong khóa (' . count($subjects) . ' môn)</h4>';
            
            echo '<div class="table-responsive">';
            echo '<table class="table table-striped table-hover">';
            echo '<thead class="table-dark">';
            echo '<tr>';
            echo '<th>ID</th>';
            echo '<th>Thông tin môn học</th>';
            echo '<th>Thời gian môn học</th>';
            echo '<th>Danh mục</th>';
            echo '<th>Thống kê</th>';
            echo '<th>Gán</th>';
            echo '<th>Thao tác</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            
            foreach ($subjects as $subject) {
                echo '<tr>';
                echo '<td>' . $subject->id . '</td>';
                
                // Thông tin môn học
                echo '<td>';
                echo '<a href="' . $CFG->wwwroot . '/course/view.php?id=' . $subject->moodle_course_id . '" target="_blank">';
                echo '<strong>' . htmlspecialchars($subject->subject_name) . '</strong>';
                echo '</a><br>';
                echo '<small class="text-muted">Mã: ' . htmlspecialchars($subject->subject_code) . '</small>';
                if ($subject->visible) {
                    echo ' <span class="badge bg-success">Hiển thị</span>';
                } else {
                    echo ' <span class="badge bg-secondary">Ẩn</span>';
                }
                if (!empty($subject->summary)) {
                    $summary = strip_tags($subject->summary);
                    if (strlen($summary) > 100) {
                        $summary = substr($summary, 0, 100) . '...';
                    }
                    echo '<br><small class="text-muted fst-italic">' . htmlspecialchars($summary) . '</small>';
                }
                echo '</td>';
                
                // Thời gian môn học
                echo '<td>';
                echo date('d/m/Y', $subject->start_date);
                if ($subject->end_date) {
                    echo '<br><small class="text-muted">đến ' . date('d/m/Y', $subject->end_date) . '</small>';
                }
                echo '<br><small class="text-muted">Import: ' . date('d/m/Y', $subject->imported_date) . '</small>';
                echo '</td>';
                
                // Danh mục
                echo '<td>' . htmlspecialchars($subject->category_name ?: 'Không có') . '</td>';
                
                // Thống kê
                echo '<td>';
                echo '<span class="badge bg-primary">' . $subject->enrolled_users . ' học viên</span><br>';
                echo '<span class="badge bg-info">' . $subject->total_activities . ' hoạt động</span>';
                echo '</td>';
                
                // Thông tin gán
                echo '<td>';
                echo '<small class="text-success">' . date('d/m/Y H:i', $subject->assigned_date) . '</small><br>';
                if ($subject->assignment_type == 'auto') {
                    echo '<span class="badge bg-success">Tự động</span>';
                } else {
                    echo '<span class="badge bg-warning">Thủ công</span>';
                }
                echo '</td>';
                
                // Thao tác
                echo '<td>';
                echo '<div class="btn-group-vertical btn-group-sm">';
                echo '<a href="' . $CFG->wwwroot . '/local/course_batches/subject_detail.php?id=' . $subject->id . '&batch_id=' . $batch_id . '" class="btn btn-info btn-sm" title="Xem chi tiết">';
                echo '<i class="fa fa-eye"></i>';
                echo '</a>';
                echo '<a href="' . $CFG->wwwroot . '/course/view.php?id=' . $subject->moodle_course_id . '" target="_blank" class="btn btn-primary btn-sm" title="Mở môn học">';
                echo '<i class="fa fa-external-link"></i>';
                echo '</a>';
                echo '<a href="' . $CFG->wwwroot . '/local/course_batches/remove_subject.php?batch_id=' . $batch_id . '&subject_id=' . $subject->id . '" class="btn btn-danger btn-sm" title="Xóa khỏi khóa học" onclick="return confirm(\'Bạn có chắc muốn xóa môn học này khỏi khóa học?\')">';
                echo '<i class="fa fa-trash"></i>';
                echo '</a>';
                echo '</div>';
                echo '</td>';
                
                echo '</tr>';
            }
            
            echo '</tbody>';
            echo '</table>';
            echo '</div>';
            
            echo '<div class="alert alert-success mt-3">';
            echo '<i class="fa fa-check-circle"></i> ';
            echo '<strong>Tổng kết:</strong> ' . count($subjects) . ' môn học trong khóa học này';
            echo '</div>';
        }
    }
} else {
    // Hiển thị danh sách khóa học
    
    // Thống kê tổng quan
    $stats = local_course_batches\course_subject_manager::get_dashboard_statistics();
    
    echo '<div class="row mb-4">';
    echo '<div class="col-md-3">';
    echo '<div class="card bg-primary text-white">';
    echo '<div class="card-body text-center">';
    echo '<h3>' . $stats['total_batches'] . '</h3>';
    echo '<p><i class="fa fa-graduation-cap"></i> Tổng khóa học</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="col-md-3">';
    echo '<div class="card bg-success text-white">';
    echo '<div class="card-body text-center">';
    echo '<h3>' . $stats['total_subjects'] . '</h3>';
    echo '<p><i class="fa fa-book"></i> Tổng môn học</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="col-md-3">';
    echo '<div class="card bg-info text-white">';
    echo '<div class="card-body text-center">';
    echo '<h3>' . $stats['assigned_subjects'] . '</h3>';
    echo '<p><i class="fa fa-check"></i> Môn học đã gán</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="col-md-3">';
    echo '<div class="card bg-warning text-white">';
    echo '<div class="card-body text-center">';
    echo '<h3>' . $stats['unassigned_subjects'] . '</h3>';
    echo '<p><i class="fa fa-clock-o"></i> Môn học chưa gán</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Danh sách khóa học
    $batches = local_course_batches\course_subject_manager::get_all_course_batches();
    
    if (empty($batches)) {
        echo '<div class="alert alert-info text-center">';
        echo '<i class="fa fa-info-circle fa-3x mb-3"></i><br>';
        echo '<h4>Chưa có khóa học nào</h4>';
        echo '<p>Hãy tạo khóa học đầu tiên của bạn</p>';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/manage.php" class="btn btn-success btn-lg">';
        echo '<i class="fa fa-plus"></i> Tạo khóa học mới';
        echo '</a>';
        echo '</div>';
    } else {
        echo '<h4><i class="fa fa-graduation-cap"></i> Danh sách khóa học (' . count($batches) . ' khóa)</h4>';
        
        echo '<div class="table-responsive">';
        echo '<table class="table table-striped table-hover">';
        echo '<thead class="table-dark">';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>Thông tin khóa học</th>';
        echo '<th>Thời gian khóa học</th>';
        echo '<th>Số môn học</th>';
        echo '<th>Trạng thái</th>';
        echo '<th>Thao tác</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($batches as $batch) {
            $subject_count = count(local_course_batches\course_subject_manager::get_subjects_in_batch($batch->id));
            
            echo '<tr>';
            echo '<td>' . $batch->id . '</td>';
            
            // Thông tin khóa học
            echo '<td>';
            echo '<strong>' . htmlspecialchars($batch->batch_name) . '</strong>';
            if (!empty($batch->description)) {
                echo '<br><small class="text-muted">' . htmlspecialchars($batch->description) . '</small>';
            }
            echo '<br><small class="text-muted">Tạo: ' . date('d/m/Y H:i', $batch->created_date) . '</small>';
            echo '</td>';
            
            // Thời gian khóa học
            echo '<td>';
            echo '<strong>' . date('d/m/Y', $batch->start_date) . '</strong>';
            echo '<br><small class="text-muted">đến ' . date('d/m/Y', $batch->end_date) . '</small>';
            
            // Tính số ngày
            $days = ceil(($batch->end_date - $batch->start_date) / (24 * 60 * 60));
            echo '<br><small class="text-info">' . $days . ' ngày</small>';
            echo '</td>';
            
            // Số môn học
            echo '<td>';
            if ($subject_count > 0) {
                echo '<span class="badge bg-primary fs-6">' . $subject_count . ' môn học</span>';
            } else {
                echo '<span class="badge bg-secondary">0 môn học</span>';
            }
            echo '</td>';
            
            // Trạng thái
            echo '<td>';
            if ($batch->status == 1) {
                echo '<span class="badge bg-success">Hoạt động</span>';
            } else {
                echo '<span class="badge bg-secondary">Không hoạt động</span>';
            }
            
            // Kiểm tra thời gian
            $now = time();
            if ($now < $batch->start_date) {
                echo '<br><span class="badge bg-info">Sắp bắt đầu</span>';
            } elseif ($now > $batch->end_date) {
                echo '<br><span class="badge bg-warning">Đã kết thúc</span>';
            } else {
                echo '<br><span class="badge bg-success">Đang diễn ra</span>';
            }
            echo '</td>';
            
            // Thao tác
            echo '<td>';
            echo '<div class="btn-group-vertical btn-group-sm">';
            echo '<a href="?action=view_subjects&id=' . $batch->id . '" class="btn btn-primary btn-sm">';
            echo '<i class="fa fa-eye"></i> Xem môn học (' . $subject_count . ')';
            echo '</a>';
            echo '<a href="' . $CFG->wwwroot . '/local/course_batches/manage.php?id=' . $batch->id . '" class="btn btn-warning btn-sm">';
            echo '<i class="fa fa-edit"></i> Sửa khóa học';
            echo '</a>';
            echo '<a href="' . $CFG->wwwroot . '/local/course_batches/auto_assign.php?batch_id=' . $batch->id . '" class="btn btn-success btn-sm">';
            echo '<i class="fa fa-magic"></i> Tự động gán môn';
            echo '</a>';
            echo '</div>';
            echo '</td>';
            
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
    }
}

echo '</div>'; // End container

echo $OUTPUT->footer();