<?php
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/batch_manager.php');

require_login();

if (!is_siteadmin()) {
    die('Chỉ admin mới có thể chạy script này.');
}

echo "<h2>Script thêm dữ liệu mẫu cho Course Batches</h2>";

// 1. Tạo các đợt mở môn mẫu
echo "<h3>1. Tạo đợt mở môn mẫu</h3>";

$batch_manager = new local_course_batches\batch_manager();

// Đợt 1
$batch1_data = new stdClass();
$batch1_data->batch_name = 'Đợt mở môn Học kỳ I 2024-2025';
$batch1_data->start_date = strtotime('2024-09-01');
$batch1_data->end_date = strtotime('2025-01-31');
$batch1_data->description = 'Đợt mở môn đầu tiên của năm học 2024-2025';

try {
    $batch1_id = $batch_manager->create_batch(
        $batch1_data->batch_name,
        $batch1_data->start_date,
        $batch1_data->end_date,
        $batch1_data->description
    );
    echo "<p>✅ Tạo đợt 1 thành công - ID: {$batch1_id}</p>";
} catch (Exception $e) {
    echo "<p>❌ Lỗi tạo đợt 1: " . $e->getMessage() . "</p>";
}

// Đợt 2
$batch2_data = new stdClass();
$batch2_data->batch_name = 'Đợt mở môn Học kỳ II 2024-2025';
$batch2_data->start_date = strtotime('2025-02-01');
$batch2_data->end_date = strtotime('2025-06-30');
$batch2_data->description = 'Đợt mở môn thứ hai của năm học 2024-2025';

try {
    $batch2_id = $batch_manager->create_batch(
        $batch2_data->batch_name,
        $batch2_data->start_date,
        $batch2_data->end_date,
        $batch2_data->description
    );
    echo "<p>✅ Tạo đợt 2 thành công - ID: {$batch2_id}</p>";
} catch (Exception $e) {
    echo "<p>❌ Lỗi tạo đợt 2: " . $e->getMessage() . "</p>";
}

// Đợt 3
$batch3_data = new stdClass();
$batch3_data->batch_name = 'Đợt mở môn Hè 2025';
$batch3_data->start_date = strtotime('2025-07-01');
$batch3_data->end_date = strtotime('2025-08-31');
$batch3_data->description = 'Đợt mở môn hè năm 2025';

try {
    $batch3_id = $batch_manager->create_batch(
        $batch3_data->batch_name,
        $batch3_data->start_date,
        $batch3_data->end_date,
        $batch3_data->description
    );
    echo "<p>✅ Tạo đợt 3 thành công - ID: {$batch3_id}</p>";
} catch (Exception $e) {
    echo "<p>❌ Lỗi tạo đợt 3: " . $e->getMessage() . "</p>";
}

// 2. Tự động gán khóa học vào các đợt
echo "<h3>2. Tự động gán khóa học vào đợt</h3>";

$batches = $batch_manager->get_all_batches();
foreach ($batches as $batch) {
    $count = $batch_manager->auto_assign_courses_by_date_range($batch->id, $batch->start_date, $batch->end_date);
    echo "<p>📝 Đợt '{$batch->batch_name}': Đã gán {$count} khóa học</p>";
}

// 3. Hiển thị kết quả
echo "<h3>3. Kết quả tổng kết</h3>";

$batches = $batch_manager->get_all_batches();
if (empty($batches)) {
    echo "<p>❌ Không có đợt mở môn nào</p>";
} else {
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
    echo "<thead>";
    echo "<tr style='background-color: #f0f0f0;'>";
    echo "<th>ID</th>";
    echo "<th>Tên đợt</th>";
    echo "<th>Thời gian</th>";
    echo "<th>Số khóa học</th>";
    echo "<th>Thao tác</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    
    foreach ($batches as $batch) {
        $courses = $batch_manager->get_courses_in_batch($batch->id);
        
        echo "<tr>";
        echo "<td>{$batch->id}</td>";
        echo "<td><strong>{$batch->batch_name}</strong></td>";
        echo "<td>" . date('d/m/Y', $batch->start_date) . " - " . date('d/m/Y', $batch->end_date) . "</td>";
        echo "<td>" . count($courses) . " khóa học</td>";
        echo "<td>";
        echo "<a href='{$CFG->wwwroot}/local/course_batches/simple_test.php?id={$batch->id}' target='_blank'>Xem chi tiết</a>";
        echo "</td>";
        echo "</tr>";
    }
    
    echo "</tbody>";
    echo "</table>";
}

// 4. Thống kê database
echo "<h3>4. Thống kê database</h3>";
$batch_count = $DB->count_records('local_course_batches');
$course_batch_count = $DB->count_records('local_course_batch_courses');
$total_courses = $DB->count_records('course') - 1; // Trừ site course

echo "<ul>";
echo "<li>Tổng số đợt mở môn: <strong>{$batch_count}</strong></li>";
echo "<li>Tổng số liên kết khóa học-đợt: <strong>{$course_batch_count}</strong></li>";
echo "<li>Tổng số khóa học trong hệ thống: <strong>{$total_courses}</strong></li>";
echo "</ul>";

echo "<hr>";
echo "<h3>5. Links hữu ích</h3>";
echo "<ul>";
echo "<li><a href='{$CFG->wwwroot}/local/course_batches/index.php'>Trang chính Course Batches</a></li>";
echo "<li><a href='{$CFG->wwwroot}/local/course_batches/simple_test.php'>Trang test đơn giản</a></li>";
echo "<li><a href='{$CFG->wwwroot}/local/course_batches/manage.php'>Tạo đợt mới</a></li>";
echo "</ul>";

echo "<div style='margin-top: 20px; padding: 10px; background-color: #d4edda; border: 1px solid #c3e6cb; border-radius: 5px;'>";
echo "<strong>✅ Script hoàn thành!</strong><br>";
echo "Bây giờ bạn có thể truy cập vào trang Course Batches để xem kết quả.";
echo "</div>";