<?php
require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/batch_manager.php');

require_login();
$context = context_system::instance();
require_capability('local/course_batches:view', $context);

$PAGE->set_url('/local/course_batches/simple_test.php');
$PAGE->set_context($context);
$PAGE->set_title('Simple Test Course Batches');
$PAGE->set_heading('Simple Test Course Batches');

echo $OUTPUT->header();

$batch_id = optional_param('id', 0, PARAM_INT);

echo '<div class="container-fluid">';
echo '<h2>Test Plugin Course Batches</h2>';

if ($batch_id > 0) {
    // Hiển thị khóa học trong đợt
    echo '<h3>Khóa học trong đợt ID: ' . $batch_id . '</h3>';
    
    $batch = local_course_batches\batch_manager::get_batch($batch_id);
    if ($batch) {
        echo '<div class="alert alert-info">';
        echo '<strong>Tên đợt:</strong> ' . htmlspecialchars($batch->batch_name) . '<br>';
        echo '<strong>Thời gian:</strong> ' . date('d/m/Y', $batch->start_date) . ' - ' . date('d/m/Y', $batch->end_date);
        echo '</div>';
        
        $courses = local_course_batches\batch_manager::get_courses_in_batch($batch_id);
        
        if (empty($courses)) {
            echo '<div class="alert alert-warning">Không có khóa học nào trong đợt này.</div>';
        } else {
            echo '<div class="table-responsive">';
            echo '<table class="table table-striped table-bordered">';
            echo '<thead class="table-dark">';
            echo '<tr>';
            echo '<th>ID</th>';
            echo '<th>Tên khóa học</th>';
            echo '<th>Mã khóa học</th>';
            echo '<th>Danh mục</th>';
            echo '<th>Học viên</th>';
            echo '<th>Hoạt động</th>';
            echo '<th>Trạng thái</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            
            foreach ($courses as $course) {
                echo '<tr>';
                echo '<td>' . $course->id . '</td>';
                echo '<td>';
                echo '<a href="' . $CFG->wwwroot . '/course/view.php?id=' . $course->id . '" target="_blank">';
                echo '<strong>' . htmlspecialchars($course->fullname) . '</strong>';
                echo '</a>';
                if (!empty($course->summary)) {
                    $summary = strip_tags($course->summary);
                    if (strlen($summary) > 100) {
                        $summary = substr($summary, 0, 100) . '...';
                    }
                    echo '<br><small class="text-muted">' . htmlspecialchars($summary) . '</small>';
                }
                echo '</td>';
                echo '<td><code>' . htmlspecialchars($course->shortname) . '</code></td>';
                echo '<td>' . htmlspecialchars($course->category_name ?: 'Không xác định') . '</td>';
                echo '<td>';
                echo '<span class="badge bg-primary">' . ($course->enrolled_users ?: '0') . ' học viên</span>';
                if (!empty($course->active_users) && $course->active_users > 0) {
                    echo '<br><span class="badge bg-success">' . $course->active_users . ' hoạt động</span>';
                }
                echo '</td>';
                echo '<td>';
                echo '<span class="badge bg-info">' . ($course->total_activities ?: '0') . ' hoạt động</span>';
                $activity_details = array();
                if (!empty($course->assignments)) $activity_details[] = $course->assignments . ' BT';
                if (!empty($course->quizzes)) $activity_details[] = $course->quizzes . ' KT';
                if (!empty($course->forums)) $activity_details[] = $course->forums . ' ĐĐ';
                if (!empty($course->resources)) $activity_details[] = $course->resources . ' TN';
                if (!empty($activity_details)) {
                    echo '<br><small>' . implode(', ', $activity_details) . '</small>';
                }
                echo '</td>';
                echo '<td>';
                if ($course->visible) {
                    echo '<span class="badge bg-success">Hiển thị</span>';
                } else {
                    echo '<span class="badge bg-secondary">Ẩn</span>';
                }
                echo '<br><small>Định dạng: ' . ($course->format ?: 'topics') . '</small>';
                echo '</td>';
                echo '</tr>';
            }
            
            echo '</tbody>';
            echo '</table>';
            echo '</div>';
            
            echo '<div class="alert alert-success mt-3">';
            echo '<i class="fa fa-check-circle"></i> ';
            echo '<strong>Tổng kết:</strong> ' . count($courses) . ' khóa học trong đợt này';
            echo '</div>';
        }
        
        echo '<div class="mt-3">';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/simple_test.php" class="btn btn-secondary">← Quay lại danh sách</a>';
        echo '</div>';
    }
} else {
    // Hiển thị danh sách đợt
    echo '<h3>Danh sách tất cả đợt mở môn</h3>';
    
    $batches = local_course_batches\batch_manager::get_all_batches();
    
    if (empty($batches)) {
        echo '<div class="alert alert-warning">';
        echo '<i class="fa fa-exclamation-triangle"></i> ';
        echo 'Chưa có đợt mở môn nào. ';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/manage.php" class="btn btn-sm btn-primary">Tạo đợt mới</a>';
        echo '</div>';
    } else {
        echo '<div class="table-responsive">';
        echo '<table class="table table-striped table-bordered">';
        echo '<thead class="table-dark">';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>Tên đợt</th>';
        echo '<th>Thời gian</th>';
        echo '<th>Mô tả</th>';
        echo '<th>Số khóa học</th>';
        echo '<th>Thao tác</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        
        foreach ($batches as $batch) {
            $course_count = count(local_course_batches\batch_manager::get_courses_in_batch($batch->id));
            
            echo '<tr>';
            echo '<td>' . $batch->id . '</td>';
            echo '<td><strong>' . htmlspecialchars($batch->batch_name) . '</strong></td>';
            echo '<td>';
            echo date('d/m/Y', $batch->start_date) . '<br>';
            echo '<small class="text-muted">đến ' . date('d/m/Y', $batch->end_date) . '</small>';
            echo '</td>';
            echo '<td>';
            if (!empty($batch->description)) {
                echo '<small>' . htmlspecialchars($batch->description) . '</small>';
            } else {
                echo '<small class="text-muted">Không có mô tả</small>';
            }
            echo '</td>';
            echo '<td>';
            if ($course_count > 0) {
                echo '<span class="badge bg-primary">' . $course_count . ' khóa học</span>';
            } else {
                echo '<span class="badge bg-secondary">0 khóa học</span>';
            }
            echo '</td>';
            echo '<td>';
            echo '<a href="?id=' . $batch->id . '" class="btn btn-sm btn-primary">Xem khóa học</a> ';
            echo '<a href="' . $CFG->wwwroot . '/local/course_batches/manage.php?id=' . $batch->id . '" class="btn btn-sm btn-warning">Sửa</a>';
            echo '</td>';
            echo '</tr>';
        }
        
        echo '</tbody>';
        echo '</table>';
        echo '</div>';
        
        echo '<div class="mt-3">';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/manage.php" class="btn btn-success">+ Tạo đợt mới</a>';
        echo '</div>';
    }
}

echo '</div>';

echo $OUTPUT->footer();