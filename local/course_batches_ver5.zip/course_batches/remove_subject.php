<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Xóa môn học khỏi khóa học
 *
 * @package    local_course_batches
 * @copyright  2025 Your Name
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/course_subject_manager.php');

require_login();
$context = context_system::instance();
require_capability('local/course_batches:manage', $context);

$batch_id = required_param('batch_id', PARAM_INT);
$subject_id = required_param('subject_id', PARAM_INT);
$confirm = optional_param('confirm', 0, PARAM_INT);

$PAGE->set_url('/local/course_batches/remove_subject.php', array(
    'batch_id' => $batch_id,
    'subject_id' => $subject_id
));
$PAGE->set_context($context);
$PAGE->set_title('Xóa môn học khỏi khóa học');
$PAGE->set_heading('Xóa môn học khỏi khóa học');

// Kiểm tra tồn tại
$batch = local_course_batches\course_subject_manager::get_course_batch($batch_id);
$subject = local_course_batches\course_subject_manager::get_subject($subject_id);

if (!$batch || !$subject) {
    throw new moodle_exception('Không tìm thấy khóa học hoặc môn học');
}

echo $OUTPUT->header();

echo '<div class="container-fluid">';

if ($confirm) {
    // Thực hiện xóa
    global $DB;
    
    $result = $DB->delete_records('local_batch_subjects', array(
        'batch_id' => $batch_id,
        'subject_id' => $subject_id
    ));
    
    if ($result) {
        echo '<div class="alert alert-success">';
        echo '<i class="fa fa-check-circle"></i> ';
        echo 'Đã xóa môn học <strong>' . htmlspecialchars($subject->subject_name) . '</strong> khỏi khóa <em>' . htmlspecialchars($batch->batch_name) . '</em>';
        echo '</div>';
        
        echo '<div class="mt-3">';
        echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php?action=view_subjects&id=' . $batch_id . '" class="btn btn-primary">';
        echo '<i class="fa fa-arrow-left"></i> Quay lại khóa học';
        echo '</a>';
        echo '</div>';
        
    } else {
        echo '<div class="alert alert-danger">';
        echo '<i class="fa fa-exclamation-triangle"></i> Có lỗi xảy ra khi xóa môn học';
        echo '</div>';
        
        echo '<div class="mt-3">';
        echo '<a href="?batch_id=' . $batch_id . '&subject_id=' . $subject_id . '" class="btn btn-primary">Thử lại</a>';
        echo '</div>';
    }
    
} else {
    // Hiển thị xác nhận
    echo '<div class="d-flex justify-content-between align-items-center mb-4">';
    echo '<h2><i class="fa fa-trash"></i> Xác nhận xóa môn học</h2>';
    echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php?action=view_subjects&id=' . $batch_id . '" class="btn btn-secondary">';
    echo '<i class="fa fa-arrow-left"></i> Quay lại';
    echo '</a>';
    echo '</div>';
    
    echo '<div class="alert alert-warning">';
    echo '<i class="fa fa-exclamation-triangle"></i> ';
    echo '<strong>Cảnh báo!</strong><br>';
    echo 'Bạn đang chuẩn bị xóa môn học khỏi khóa học. Hành động này chỉ xóa liên kết giữa môn học và khóa học, không xóa môn học trong Moodle.';
    echo '</div>';
    
    // Thông tin khóa học
    echo '<div class="row">';
    echo '<div class="col-md-6">';
    echo '<div class="card">';
    echo '<div class="card-header bg-primary text-white">';
    echo '<h5><i class="fa fa-graduation-cap"></i> Khóa học</h5>';
    echo '</div>';
    echo '<div class="card-body">';
    echo '<h6>' . htmlspecialchars($batch->batch_name) . '</h6>';
    echo '<p class="text-muted">' . date('d/m/Y', $batch->start_date) . ' - ' . date('d/m/Y', $batch->end_date) . '</p>';
    if (!empty($batch->description)) {
        echo '<p><small>' . htmlspecialchars($batch->description) . '</small></p>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    echo '<div class="col-md-6">';
    echo '<div class="card">';
    echo '<div class="card-header bg-info text-white">';
    echo '<h5><i class="fa fa-book"></i> Môn học</h5>';
    echo '</div>';
    echo '<div class="card-body">';
    echo '<h6>' . htmlspecialchars($subject->subject_name) . '</h6>';
    echo '<p class="text-muted">Mã: ' . htmlspecialchars($subject->subject_code) . '</p>';
    echo '<p>Thời gian: ' . date('d/m/Y', $subject->start_date);
    if ($subject->end_date) {
        echo ' - ' . date('d/m/Y', $subject->end_date);
    }
    echo '</p>';
    
    if (!empty($subject->summary)) {
        $summary = strip_tags($subject->summary);
        if (strlen($summary) > 150) {
            $summary = substr($summary, 0, 150) . '...';
        }
        echo '<p><small>' . htmlspecialchars($summary) . '</small></p>';
    }
    
    echo '<p>';
    echo '<span class="badge bg-primary">' . $subject->enrolled_users . ' học viên</span> ';
    echo '<span class="badge bg-info">' . $subject->total_activities . ' hoạt động</span>';
    echo '</p>';
    
    echo '<a href="' . $CFG->wwwroot . '/course/view.php?id=' . $subject->moodle_course_id . '" target="_blank" class="btn btn-sm btn-outline-primary">';
    echo '<i class="fa fa-external-link"></i> Mở môn học trong Moodle';
    echo '</a>';
    
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
    // Nút xác nhận
    echo '<div class="mt-4 text-center">';
    echo '<div class="alert alert-danger">';
    echo '<i class="fa fa-exclamation-triangle"></i> ';
    echo '<strong>Xác nhận xóa</strong><br>';
    echo 'Bạn có chắc chắn muốn xóa môn học <em>' . htmlspecialchars($subject->subject_name) . '</em> khỏi khóa <em>' . htmlspecialchars($batch->batch_name) . '</em>?';
    echo '</div>';
    
    echo '<a href="?batch_id=' . $batch_id . '&subject_id=' . $subject_id . '&confirm=1" class="btn btn-danger btn-lg me-3">';
    echo '<i class="fa fa-trash"></i> Xác nhận xóa';
    echo '</a>';
    echo '<a href="' . $CFG->wwwroot . '/local/course_batches/index.php?action=view_subjects&id=' . $batch_id . '" class="btn btn-secondary btn-lg">';
    echo '<i class="fa fa-times"></i> Hủy bỏ';
    echo '</a>';
    echo '</div>';
}

echo '</div>'; // End container

echo $OUTPUT->footer();